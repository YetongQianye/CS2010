#ifndef __BMP_H__
#define __BMP_H__

//仅仅是显示一个图片
//void lcd_draw_bmp();
//把名字为name的bmp图片显示到(x0,y0)的位置,图片的大小为w*h
//void lcd_draw_bmp(int x0,int y0,int w,int h,char *name);

//把名字为name的bmp图片显示到(x0,y0)的位置
void lcd_draw_bmp(int x0,int y0,char *name);




#endif











